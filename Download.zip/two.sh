#!/bin/bash
export LANG=C
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none
sudo apt-get update
sudo apt-get upgrade
sudo apt-get --allow-unauthenticated install openmediavault-keyring
sudo apt-get update
sudo apt-get --yes --force-yes --auto-remove --show-upgraded \
	--no-install-recommends \
	--option Dpkg::Options::="--force-confdef" \
	--option DPkg::Options::="--force-confold" \
	install postfix openmediavault
# Initialize the system and database.
sudo dpkg-reconfigure openmediavault
sudo omv-initsystem